<template>
    <div>
        404
    </div>
</template>
