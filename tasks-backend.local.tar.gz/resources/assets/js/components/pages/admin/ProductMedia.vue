<template>
    <div>
        Product Media {{ $route.params.product_id }}
    </div>
</template>
